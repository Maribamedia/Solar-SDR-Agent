import React, { useState } from 'react';
import { format } from 'date-fns';
import { Bot, User, ExternalLink, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { Message } from '../types';

interface ChatMessageProps {
  message: Message;
  onWebhookTrigger?: (webhookUrl: string) => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onWebhookTrigger }) => {
  const [showWebhookResponse, setShowWebhookResponse] = useState(false);
  const isBot = message.role === 'assistant';
  const isError = message.content.toLowerCase().includes('error') || message.content.toLowerCase().includes('apologize');

  return (
    <div className={`flex gap-4 p-6 ${isBot ? 'bg-gray-50' : 'bg-white'} ${isError ? 'bg-red-50' : ''}`}>
      <div className="flex-shrink-0">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
          isBot 
            ? isError 
              ? 'bg-red-100 text-red-600'
              : 'bg-green-100 text-green-600' 
            : 'bg-blue-100 text-blue-600'
        }`}>
          {isBot 
            ? isError 
              ? <AlertCircle size={20} />
              : <Bot size={20} />
            : <User size={20} />
          }
        </div>
      </div>
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <span className="font-medium">{isBot ? 'Solar AI Agent' : 'You'}</span>
          <span className="text-xs text-gray-500">
            {format(message.timestamp, 'h:mm a')}
          </span>
        </div>
        <div className={`prose prose-sm max-w-none ${isError ? 'text-red-600' : ''}`}>
          {message.content}
        </div>
        
        {message.webhookUrl && !isError && (
          <div className="mt-2">
            <button
              onClick={() => onWebhookTrigger?.(message.webhookUrl!)}
              className="inline-flex items-center gap-2 text-sm text-green-600 hover:text-green-700"
            >
              <ExternalLink size={16} />
              Trigger Webhook
            </button>
          </div>
        )}

        {message.webhookResponse && (
          <div className="mt-2">
            <button
              onClick={() => setShowWebhookResponse(!showWebhookResponse)}
              className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-gray-700"
            >
              {showWebhookResponse ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              Webhook Response
            </button>
            
            {showWebhookResponse && (
              <pre className="mt-2 p-3 bg-gray-800 text-gray-100 rounded-lg text-sm overflow-x-auto">
                {JSON.stringify(message.webhookResponse, null, 2)}
              </pre>
            )}
          </div>
        )}
      </div>
    </div>
  );
};