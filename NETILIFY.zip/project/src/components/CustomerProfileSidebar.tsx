import React from 'react';
import { CustomerProfile } from '../types';
import { User, MapPin, Home, Zap, Calendar } from 'lucide-react';

interface CustomerProfileSidebarProps {
  profile: CustomerProfile;
}

export const CustomerProfileSidebar: React.FC<CustomerProfileSidebarProps> = ({ profile }) => {
  return (
    <div className="w-80 border-l bg-white p-6 space-y-6">
      <div className="text-lg font-semibold border-b pb-4">Customer Profile</div>
      
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <User className="text-gray-400" size={20} />
          <div>
            <div className="text-sm text-gray-500">Name</div>
            <div className="font-medium">{profile.name || 'Not provided'}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <MapPin className="text-gray-400" size={20} />
          <div>
            <div className="text-sm text-gray-500">Location</div>
            <div className="font-medium">{profile.location || 'Not provided'}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Home className="text-gray-400" size={20} />
          <div>
            <div className="text-sm text-gray-500">Roof Type</div>
            <div className="font-medium">{profile.roofType || 'Not provided'}</div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Zap className="text-gray-400" size={20} />
          <div>
            <div className="text-sm text-gray-500">Monthly Energy Bill</div>
            <div className="font-medium">
              {profile.energyBill ? `$${profile.energyBill}` : 'Not provided'}
            </div>
          </div>
        </div>

        {profile.interests && profile.interests.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm text-gray-500">Interests</div>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((interest, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-sm"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>
        )}

        {profile.lastInteraction && (
          <div className="flex items-center gap-3">
            <Calendar className="text-gray-400" size={20} />
            <div>
              <div className="text-sm text-gray-500">Last Interaction</div>
              <div className="font-medium">
                {format(profile.lastInteraction, 'MMM d, yyyy')}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};