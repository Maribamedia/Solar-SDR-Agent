import { useState, useCallback } from 'react';
import { WebhookConfig } from '../types';
import { callWebhook, WebhookError } from '../services/webhookService';

interface WebhookState {
  isLoading: boolean;
  error: WebhookError | null;
  data: any | null;
}

export function useWebhook() {
  const [state, setState] = useState<WebhookState>({
    isLoading: false,
    error: null,
    data: null,
  });

  const execute = useCallback(async (config: WebhookConfig) => {
    setState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const data = await callWebhook(config);
      setState({ isLoading: false, error: null, data });
      return data;
    } catch (error) {
      const webhookError = error instanceof WebhookError 
        ? error 
        : new WebhookError('Failed to execute webhook');
      
      setState({ isLoading: false, error: webhookError, data: null });
      throw webhookError;
    }
  }, []);

  return {
    ...state,
    execute,
  };
}