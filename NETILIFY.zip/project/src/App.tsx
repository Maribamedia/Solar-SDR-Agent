import React, { useState, useRef, useEffect } from 'react';
import { Message, CustomerProfile, WebhookConfig } from './types';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { CustomerProfileSidebar } from './components/CustomerProfileSidebar';
import { Sun } from 'lucide-react';
import { useWebhook } from './hooks/useWebhook';
import { WebhookError } from './services/webhookService';

// Example webhook endpoints (replace with your actual endpoints)
const WEBHOOKS = {
  SOLAR_QUOTE: 'https://api.example.com/solar-quote',
  ENERGY_ANALYSIS: 'https://api.example.com/energy-analysis',
  INCENTIVES: 'https://api.example.com/solar-incentives',
};

function App() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: "Hello! I'm your Solar Energy Consultant. I'd love to help you explore solar options for your home. To get started, could you tell me a bit about your current energy usage and location?",
      timestamp: new Date(),
      webhookUrl: WEBHOOKS.ENERGY_ANALYSIS,
    },
  ]);
  
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const webhook = useWebhook();
  
  const [profile, setProfile] = useState<CustomerProfile>({
    id: '1',
    interests: ['Cost Savings', 'Environmental Impact'],
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleWebhookError = (error: WebhookError) => {
    const errorMessage = {
      id: Date.now().toString(),
      role: 'assistant' as const,
      content: `I apologize, but I encountered an error while processing your request: ${error.message}. Please try again or contact support if the issue persists.`,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, errorMessage]);
  };

  const handleWebhookTrigger = async (webhookUrl: string) => {
    try {
      setIsTyping(true);

      const config: WebhookConfig = {
        url: webhookUrl,
        method: 'POST',
        headers: {
          'Authorization': 'Bearer your-token-here',
        },
        body: {
          profileId: profile.id,
          timestamp: new Date().toISOString(),
        },
      };

      const webhookResponse = await webhook.execute(config);

      // Update the message with the webhook response
      setMessages(prev => prev.map(msg => 
        msg.webhookUrl === webhookUrl 
          ? { ...msg, webhookResponse }
          : msg
      ));

      // Add a new message from the assistant based on the webhook response
      const responseMessage = {
        id: Date.now().toString(),
        role: 'assistant' as const,
        content: generateResponseFromWebhook(webhookUrl, webhookResponse),
        timestamp: new Date(),
        webhookUrl: getNextWebhook(webhookUrl),
      };
      
      setMessages(prev => [...prev, responseMessage]);
      
    } catch (error) {
      if (error instanceof WebhookError) {
        handleWebhookError(error);
      } else {
        handleWebhookError(new WebhookError('An unexpected error occurred'));
      }
    } finally {
      setIsTyping(false);
    }
  };

  // Rest of the code remains the same...
  const getNextWebhook = (currentWebhook: string) => {
    if (currentWebhook === WEBHOOKS.ENERGY_ANALYSIS) {
      return WEBHOOKS.SOLAR_QUOTE;
    } else if (currentWebhook === WEBHOOKS.SOLAR_QUOTE) {
      return WEBHOOKS.INCENTIVES;
    }
    return WEBHOOKS.ENERGY_ANALYSIS;
  };

  const generateResponseFromWebhook = (webhookUrl: string, response: any) => {
    if (webhookUrl === WEBHOOKS.SOLAR_QUOTE) {
      return `Based on our analysis, we recommend a ${response.systemSize} solar system. The estimated cost would be $${response.estimatedCost} with monthly payments of $${response.monthlyPayment}. You'll see a return on investment in ${response.paybackPeriod} with annual savings of $${response.annualSavings}. Would you like to explore available incentives?`;
    } else if (webhookUrl === WEBHOOKS.ENERGY_ANALYSIS) {
      return `I see that your current energy usage is ${response.currentUsage} with peak consumption during ${response.peakHours}. A ${response.recommendedSystemSize} system could reduce your bills by ${response.potentialSavings} and save ${response.co2Reduction} in CO2 emissions. Would you like to see a detailed quote?`;
    } else if (webhookUrl === WEBHOOKS.INCENTIVES) {
      return `Great news! You qualify for several incentives: a ${response.federalTaxCredit} federal tax credit, ${response.stateTaxCredit} state tax credit, and a ${response.utilityRebate} utility rebate. With ${response.netMetering} net metering, your total savings could be ${response.estimatedTotalSavings}. Would you like to schedule a consultation to proceed?`;
    }
    return "I've analyzed the data. What specific aspect would you like to explore further?";
  };

  const simulateResponse = async (userMessage: string) => {
    setIsTyping(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    let response = '';
    let webhookUrl = WEBHOOKS.ENERGY_ANALYSIS;
    
    if (userMessage.toLowerCase().includes('cost')) {
      response = "I'll analyze the potential costs and savings for your solar installation. Click the webhook trigger below to see the detailed breakdown.";
      webhookUrl = WEBHOOKS.SOLAR_QUOTE;
      setProfile(prev => ({
        ...prev,
        interests: [...(prev.interests || []), 'Cost Analysis'],
      }));
    } else if (userMessage.toLowerCase().includes('incentive')) {
      response = "Let me check the available solar incentives in your area. Click the webhook trigger to see current programs and savings.";
      webhookUrl = WEBHOOKS.INCENTIVES;
    } else {
      response = "I'll analyze your energy usage patterns to recommend the optimal solar solution. Click the webhook trigger below to see the analysis.";
    }
    
    setMessages(prev => [...prev, {
      id: Date.now().toString(),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
      webhookUrl,
    }]);
    
    setIsTyping(false);
  };

  const handleSendMessage = (content: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, newMessage]);
    simulateResponse(content);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      <div className="flex-1 flex flex-col">
        <header className="bg-white border-b px-6 py-4">
          <div className="flex items-center gap-3 max-w-4xl mx-auto">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
              <Sun className="text-green-600" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-semibold">Solar AI Assistant</h1>
              <p className="text-sm text-gray-500">Building a sustainable future together</p>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
          <div className="max-w-4xl mx-auto">
            {messages.map((message) => (
              <ChatMessage 
                key={message.id} 
                message={message} 
                onWebhookTrigger={handleWebhookTrigger}
              />
            ))}
            {isTyping && (
              <div className="p-6 text-gray-500">
                Solar AI is typing...
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <ChatInput onSend={handleSendMessage} disabled={isTyping} />
      </div>
      
      <CustomerProfileSidebar profile={profile} />
    </div>
  );
}

export default App;