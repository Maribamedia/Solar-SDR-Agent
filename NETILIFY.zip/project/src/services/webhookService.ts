import { WebhookConfig } from '../types';

export class WebhookError extends Error {
  constructor(
    message: string,
    public status?: number,
    public data?: any
  ) {
    super(message);
    this.name = 'WebhookError';
  }
}

const DEFAULT_TIMEOUT = 30000; // 30 seconds
const MAX_RETRIES = 2;
const RETRY_DELAY = 1000; // 1 second

export async function callWebhook(config: WebhookConfig, retryCount = 0): Promise<any> {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT);

  try {
    const response = await fetch(config.url, {
      method: config.method || 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...config.headers,
      },
      body: config.body ? JSON.stringify(config.body) : undefined,
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new WebhookError(
        `Request failed with status ${response.status}`,
        response.status,
        await response.json().catch(() => null)
      );
    }

    const data = await response.json();
    return data;
  } catch (error) {
    if (error instanceof WebhookError) {
      // If it's a client error (4xx), don't retry
      if (error.status && error.status >= 400 && error.status < 500) {
        throw error;
      }
    }

    // Retry logic for network errors or 5xx errors
    if (retryCount < MAX_RETRIES) {
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)));
      return callWebhook(config, retryCount + 1);
    }

    if (error instanceof Error) {
      if (error.name === 'AbortError') {
        throw new WebhookError('Request timed out');
      }
      throw new WebhookError(error.message);
    }
    
    throw new WebhookError('Unknown error occurred');
  } finally {
    clearTimeout(timeoutId);
  }
}