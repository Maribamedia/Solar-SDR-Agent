export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  webhookUrl?: string;
  webhookResponse?: any;
}

export interface CustomerProfile {
  id: string;
  name?: string;
  email?: string;
  location?: string;
  roofType?: string;
  energyBill?: number;
  interests?: string[];
  lastInteraction?: Date;
}

export interface WebhookConfig {
  url: string;
  method?: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: any;
}